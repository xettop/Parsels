package ua.parcels.tracker.net

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import ua.parcels.tracker.data.AppSettings
import ua.parcels.tracker.data.Carrier
import ua.parcels.tracker.data.Parcel
import ua.parcels.tracker.data.State
import java.io.IOException
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.TimeUnit

data class TrackResult(
    val status: String = "",
    val state: State = State.UNKNOWN,
    val location: String = "",
    val note: String = "",
    val eventTime: Long? = null,
    val error: String? = null,
)

object Trackers {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .callTimeout(30, TimeUnit.SECONDS)
        .build()

    private class Http(val code: Int, val body: String)

    private fun exec(req: Request): Http =
        client.newCall(req).execute().use { Http(it.code, it.body?.string().orEmpty()) }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    /** Блокирующий вызов — запускать на Dispatchers.IO. */
    fun track(p: Parcel, s: AppSettings): TrackResult = try {
        when (p.carrierEnum) {
            Carrier.NOVA -> nova(p, s)
            Carrier.UKR -> ukr(p, s)
            Carrier.MEEST -> meest(p)
        }
    } catch (e: IOException) {
        TrackResult(error = "Нет связи с сервером: ${e.message ?: "ошибка сети"}")
    } catch (e: Exception) {
        TrackResult(error = "Ошибка разбора ответа: ${e.message ?: e.javaClass.simpleName}")
    }

    // ---------------------------------------------------------------- Нова Пошта

    private fun nova(p: Parcel, s: AppSettings): TrackResult {
        val doc = JSONObject().put("DocumentNumber", p.number).put("Phone", p.phone)
        val body = JSONObject()
            .put("apiKey", s.npKey)
            .put("modelName", "TrackingDocument")
            .put("calledMethod", "getStatusDocuments")
            .put("methodProperties", JSONObject().put("Documents", JSONArray().put(doc)))
        val req = Request.Builder()
            .url("https://api.novaposhta.ua/v2.0/json/")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        val r = exec(req)
        if (r.code !in 200..299) return TrackResult(error = "Нова Пошта: HTTP ${r.code}")
        val j = JSONObject(r.body)
        if (!j.optBoolean("success")) {
            val msg = j.optJSONArray("errors")?.optString(0)?.takeIf { it.isNotBlank() } ?: "ошибка API"
            return TrackResult(error = "Нова Пошта: $msg")
        }
        val d = j.optJSONArray("data")?.optJSONObject(0)
            ?: return TrackResult(error = "Нова Пошта: пустой ответ")

        val code = d.str("StatusCode").toIntOrNull() ?: 0
        val status = d.str("Status")
        val state = when (code) {
            9, 10, 11 -> State.DELIVERED
            7, 8 -> State.READY
            2, 102, 103, 105, 106, 108 -> State.PROBLEM
            3 -> State.UNKNOWN // номер не найден (возможно, ещё не появился в системе)
            0 -> classify(status)
            else -> State.TRANSIT
        }
        val location = d.str("WarehouseRecipient")
            .ifBlank { d.str("WarehouseRecipientAddress") }
            .ifBlank { d.str("CityRecipient") }
        val eventTime = parseDate(d.str("TrackingUpdateDate")) ?: parseDate(d.str("DateScan"))

        val noteParts = mutableListOf<String>()
        parseDate(d.str("DateFirstDayStorage"))?.let {
            if (state == State.READY) {
                noteParts += "Бесплатное хранение до ${SimpleDateFormat("dd.MM", Locale.US).format(it)}"
            }
        }
        d.str("ScheduledDeliveryDate").takeIf { it.isNotBlank() && state == State.TRANSIT }?.let {
            parseDate(it)?.let { ts ->
                noteParts += "Ожидается ${SimpleDateFormat("dd.MM", Locale.US).format(ts)}"
            }
        }
        return TrackResult(status, state, location, noteParts.joinToString(" · "), eventTime)
    }

    // ---------------------------------------------------------------- Укрпошта

    private fun ukr(p: Parcel, s: AppSettings): TrackResult {
        if (s.upToken.isBlank()) {
            return TrackResult(error = "Укрпошта: укажите Bearer-токен статус-трекинга в настройках")
        }
        val req = Request.Builder()
            .url("https://www.ukrposhta.ua/status-tracking/0.0.1/statuses/last?barcode=${enc(p.number)}")
            .header("Authorization", "Bearer ${s.upToken}")
            .header("Accept", "application/json")
            .get()
            .build()
        val r = exec(req)
        when {
            r.code == 401 || r.code == 403 -> return TrackResult(error = "Укрпошта: токен не принят (HTTP ${r.code})")
            r.code == 404 -> return TrackResult(status = "Не найдена в системе", state = State.UNKNOWN)
            r.code !in 200..299 -> return TrackResult(error = "Укрпошта: HTTP ${r.code}")
        }
        val text = r.body.trim()
        if (text.isEmpty()) return TrackResult(status = "Нет данных", state = State.UNKNOWN)

        val o: JSONObject = if (text.startsWith("[")) {
            val arr = JSONArray(text)
            var best: JSONObject? = null
            var bestTs = Long.MIN_VALUE
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val ts = parseDate(item.str("date")) ?: Long.MIN_VALUE
                if (best == null || ts >= bestTs) {
                    best = item; bestTs = ts
                }
            }
            best ?: return TrackResult(status = "Нет данных", state = State.UNKNOWN)
        } else JSONObject(text)

        val name = o.str("eventName")
        if (name.isBlank()) {
            val msg = o.str("message").ifBlank { o.str("error") }
            return if (msg.isNotBlank()) TrackResult(status = msg, state = State.UNKNOWN)
            else TrackResult(status = "Нет данных", state = State.UNKNOWN)
        }
        val reason = o.str("eventReason")
        val status = if (reason.isNotBlank()) "$name ($reason)" else name
        val place = o.str("name")
        val index = o.str("index")
        val location = when {
            place.isNotBlank() && index.isNotBlank() -> "$place, $index"
            else -> place.ifBlank { index }
        }
        return TrackResult(status, classify(status), location, "", parseDate(o.str("date")))
    }

    // ---------------------------------------------------------------- Meest

    private val MEEST_DATE_KEYS = listOf("date", "datetime", "datetimeutc", "time", "created", "createdat", "timestamp", "eventdate", "actiondate", "dateevent")
    private val MEEST_TEXT_KEYS = listOf("status", "statusname", "statustext", "actionmessage", "message", "description", "text", "eventname", "event", "title", "name")
    private val MEEST_PLACE_KEYS = listOf("city", "cityname", "location", "place", "branch", "branchname", "office", "department", "address")

    private fun meest(p: Parcel): TrackResult {
        val req = Request.Builder()
            .url("https://publicapi.meest.com/tracking/${enc(p.number)}")
            .header("Accept", "application/json")
            .get()
            .build()
        val r = exec(req)
        if (r.code == 404) return TrackResult(status = "Не найдена в системе", state = State.UNKNOWN)
        if (r.code !in 200..299) return TrackResult(error = "Meest: HTTP ${r.code}")

        val root = JSONTokener(r.body).nextValue()
        val events = mutableListOf<JSONObject>()
        collectEvents(root, events)
        if (events.isEmpty() && root is JSONObject) {
            (root.optJSONObject("result") ?: root).let { events += it }
        }
        // Берём самое свежее событие по дате; если дат нет — первое в списке.
        var best: JSONObject? = null
        var bestTs = Long.MIN_VALUE
        for (e in events) {
            val ts = findByKeys(e, MEEST_DATE_KEYS)?.let { parseDate(it) } ?: Long.MIN_VALUE
            if (best == null || ts > bestTs) {
                best = e; bestTs = ts
            }
        }
        val ev = best
        val text = ev?.let { findByKeys(it, MEEST_TEXT_KEYS) }.orEmpty()
        if (ev == null || text.isBlank()) {
            return TrackResult(error = "Meest: не удалось разобрать ответ (${r.body.take(100)})")
        }
        val place = findByKeys(ev, MEEST_PLACE_KEYS).orEmpty()
        return TrackResult(text, classify(text), place, "", bestTs.takeIf { it != Long.MIN_VALUE })
    }

    private fun collectEvents(node: Any?, out: MutableList<JSONObject>) {
        when (node) {
            is JSONArray -> for (i in 0 until node.length()) {
                val item = node.opt(i)
                if (item is JSONObject) out += item
                collectEvents(item, out)
            }
            is JSONObject -> node.keys().forEach { collectEvents(node.opt(it), out) }
        }
    }

    /** Ищет первое непустое строковое значение по списку ключей (без учёта регистра). */
    private fun findByKeys(o: JSONObject, keys: List<String>): String? {
        val map = HashMap<String, Any?>()
        o.keys().forEach { map[it.lowercase(Locale.ROOT)] = o.opt(it) }
        for (k in keys) {
            val v = map[k] ?: continue
            when (v) {
                is String -> if (v.isNotBlank() && v != "null") return v.trim()
                is JSONObject -> v.str("name").ifBlank { v.str("text") }.takeIf { it.isNotBlank() }?.let { return it }
                is Number -> if (k.contains("time") || k.contains("date")) return v.toString()
            }
        }
        return null
    }
}
