package ua.parcels.tracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import ua.parcels.tracker.ui.AppTheme
import ua.parcels.tracker.ui.MainScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: MainVm = viewModel()
            val settings by vm.settings.collectAsState()
            AppTheme(settings.theme) {
                MainScreen(vm)
            }
        }
    }
}
