package ua.parcels.tracker

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import ua.parcels.tracker.data.AppDb
import ua.parcels.tracker.data.AppSettings
import ua.parcels.tracker.data.Carrier
import ua.parcels.tracker.data.Parcel
import ua.parcels.tracker.data.State
import ua.parcels.tracker.net.TrackResult
import ua.parcels.tracker.net.Trackers

class MainVm(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()
    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)

    val settings = MutableStateFlow(loadSettings())
    val active = dao.observe(false).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val archived = dao.observe(true).stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** Счётчик выполняющихся сетевых операций (>0 — идёт обновление). */
    val busy = MutableStateFlow(0)

    private val msgChannel = Channel<String>(Channel.BUFFERED)
    val messages = msgChannel.receiveAsFlow()

    init {
        // Автообновление при открытии приложения.
        viewModelScope.launch {
            delay(400)
            refreshAll(silent = true)
        }
    }

    private fun loadSettings() = AppSettings(
        npKey = prefs.getString("npKey", "") ?: "",
        upToken = prefs.getString("upToken", "") ?: "",
        t17Key = prefs.getString("t17Key", "") ?: "",
        theme = prefs.getString("theme", "dark") ?: "dark",
        overdueDays = prefs.getInt("overdueDays", 4),
        autoArchive = prefs.getBoolean("autoArchive", true),
    )

    fun saveSettings(s: AppSettings) {
        settings.value = s
        prefs.edit()
            .putString("npKey", s.npKey.trim())
            .putString("upToken", s.upToken.trim())
            .putString("t17Key", s.t17Key.trim())
            .putString("theme", s.theme)
            .putInt("overdueDays", s.overdueDays)
            .putBoolean("autoArchive", s.autoArchive)
            .apply()
    }

    fun add(number: String, title: String, carrier: Carrier, phone: String) {
        viewModelScope.launch {
            val n = number.trim().replace(" ", "").uppercase()
            if (n.isEmpty()) return@launch
            if (dao.count(n) > 0) {
                msgChannel.trySend("Такая посылка уже есть в списке")
                return@launch
            }
            val id = dao.insert(
                Parcel(number = n, carrier = carrier.name, title = title.trim(), phone = phone.trim())
            )
            refreshOne(id)
        }
    }

    fun refreshOne(id: Long) {
        viewModelScope.launch {
            val p = dao.get(id) ?: return@launch
            busy.update { it + 1 }
            try {
                val s = settings.value
                val r = withContext(Dispatchers.IO) { Trackers.track(p, s) }
                saveResult(id, r, s)
                r.error?.let { msgChannel.trySend(it) }
            } finally {
                busy.update { it - 1 }
            }
        }
    }

    fun refreshAll(silent: Boolean = false) {
        if (busy.value > 0) return
        viewModelScope.launch {
            val list = dao.getActive().filter { it.stateEnum != State.DELIVERED }
            if (list.isEmpty()) {
                if (!silent) msgChannel.trySend("Нет посылок для обновления")
                return@launch
            }
            busy.update { it + 1 }
            try {
                val s = settings.value
                val sem = Semaphore(4)
                val results = coroutineScope {
                    list.map { p ->
                        async(Dispatchers.IO) {
                            sem.withPermit {
                                val r = Trackers.track(p, s)
                                saveResult(p.id, r, s) to (r.error != null)
                            }
                        }
                    }.awaitAll()
                }
                val changed = results.count { it.first }
                val errors = results.count { it.second }
                if (!silent || changed > 0 || errors > 0) {
                    msgChannel.trySend(
                        buildString {
                            append("Обновлено: ${list.size}")
                            if (changed > 0) append(", новых статусов: $changed")
                            if (errors > 0) append(", ошибок: $errors")
                        }
                    )
                }
            } finally {
                busy.update { it - 1 }
            }
        }
    }

    /** Сохраняет результат проверки. Возвращает true, если статус изменился. */
    private suspend fun saveResult(id: Long, r: TrackResult, s: AppSettings): Boolean {
        val cur = dao.get(id) ?: return false
        val now = System.currentTimeMillis()
        if (r.error != null) {
            dao.update(cur.copy(error = r.error, lastChecked = now))
            return false
        }
        val readySince = if (r.state == State.READY) {
            if (cur.stateEnum == State.READY && cur.readySince != null) cur.readySince
            else r.eventTime ?: now
        } else null
        val changed = r.status != cur.status
        dao.update(
            cur.copy(
                status = r.status,
                state = r.state.name,
                location = r.location,
                note = r.note,
                readySince = readySince,
                lastChecked = now,
                lastChange = if (changed) (r.eventTime ?: now) else cur.lastChange,
                error = null,
                archived = cur.archived || (s.autoArchive && r.state == State.DELIVERED),
            )
        )
        return changed && cur.status.isNotEmpty()
    }

    fun setArchived(p: Parcel, value: Boolean) {
        viewModelScope.launch { dao.get(p.id)?.let { dao.update(it.copy(archived = value)) } }
    }

    fun delete(p: Parcel) {
        viewModelScope.launch { dao.delete(p) }
    }
}
