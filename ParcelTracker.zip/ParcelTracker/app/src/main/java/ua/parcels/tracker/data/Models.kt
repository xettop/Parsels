package ua.parcels.tracker.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class Carrier(val title: String) {
    NOVA("Нова Пошта"),
    UKR("Укрпошта"),
    MEEST("Meest");

    fun siteUrl(number: String): String = when (this) {
        NOVA -> "https://novaposhta.ua/tracking/?cargo_number=$number"
        UKR -> "https://track.ukrposhta.ua/tracking_UA.html?barcode=$number"
        MEEST -> "https://t.meest.com/?track=$number"
    }

    companion object {
        /** Грубая подсказка перевозчика по формату номера. */
        fun guess(raw: String): Carrier? {
            val n = raw.trim().replace(" ", "").uppercase()
            if (n.length < 8) return null
            return when {
                n.matches(Regex("\\d{14}")) -> NOVA
                n.matches(Regex("\\d{13}")) -> UKR
                n.matches(Regex("[A-Z]{2}\\d{9}UA")) -> UKR
                n.startsWith("CV") || n.startsWith("MS") || n.startsWith("CN") -> MEEST
                else -> null
            }
        }
    }
}

enum class State { UNKNOWN, TRANSIT, READY, DELIVERED, PROBLEM }

const val DAY_MS = 24L * 60 * 60 * 1000

@Entity(tableName = "parcels")
data class Parcel(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val number: String,
    val carrier: String,
    val title: String = "",
    val phone: String = "",
    val status: String = "",
    val state: String = State.UNKNOWN.name,
    val location: String = "",
    val note: String = "",
    /** Когда посылка стала доступна к выдаче (мс). null, если не в статусе «готова к выдаче». */
    val readySince: Long? = null,
    val lastChecked: Long? = null,
    val lastChange: Long? = null,
    val error: String? = null,
    val archived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
) {
    val stateEnum: State
        get() = runCatching { State.valueOf(state) }.getOrDefault(State.UNKNOWN)

    val carrierEnum: Carrier
        get() = runCatching { Carrier.valueOf(carrier) }.getOrDefault(Carrier.NOVA)

    fun readyDays(now: Long): Int? =
        if (stateEnum == State.READY && readySince != null) ((now - readySince) / DAY_MS).toInt().coerceAtLeast(0) else null

    /** Лежит в точке выдачи дольше порога (по умолчанию 4 суток). */
    fun isOverdue(now: Long, thresholdDays: Int): Boolean =
        stateEnum == State.READY && readySince != null && now - readySince > thresholdDays * DAY_MS
}

data class AppSettings(
    val npKey: String = "",
    val upToken: String = "",
    val theme: String = "dark", // dark | light | system
    val overdueDays: Int = 4,
    val autoArchive: Boolean = true,
)
