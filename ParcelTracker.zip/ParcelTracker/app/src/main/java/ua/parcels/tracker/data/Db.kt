package ua.parcels.tracker.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ParcelDao {
    @Query("SELECT * FROM parcels WHERE archived = :archived ORDER BY createdAt DESC")
    fun observe(archived: Boolean): Flow<List<Parcel>>

    @Query("SELECT * FROM parcels WHERE archived = 0")
    suspend fun getActive(): List<Parcel>

    @Query("SELECT * FROM parcels WHERE id = :id")
    suspend fun get(id: Long): Parcel?

    @Query("SELECT COUNT(*) FROM parcels WHERE number = :number")
    suspend fun count(number: String): Int

    @Insert
    suspend fun insert(p: Parcel): Long

    @Update
    suspend fun update(p: Parcel)

    @Delete
    suspend fun delete(p: Parcel)
}

@Database(entities = [Parcel::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): ParcelDao

    companion object {
        @Volatile private var inst: AppDb? = null

        fun get(ctx: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "parcels.db")
                .build().also { inst = it }
        }
    }
}
