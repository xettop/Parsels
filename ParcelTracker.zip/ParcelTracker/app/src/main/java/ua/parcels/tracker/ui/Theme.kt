package ua.parcels.tracker.ui

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkScheme = darkColorScheme(
    primary = Color(0xFF82B1FF),
    onPrimary = Color(0xFF00255C),
    primaryContainer = Color(0xFF1C3A6B),
    background = Color(0xFF0F1115),
    onBackground = Color(0xFFE6E8EC),
    surface = Color(0xFF171A20),
    onSurface = Color(0xFFE6E8EC),
    surfaceVariant = Color(0xFF222630),
    onSurfaceVariant = Color(0xFFA9B0BD),
    outlineVariant = Color(0xFF343A47),
)

private val LightScheme = lightColorScheme(
    primary = Color(0xFF1565C0),
    background = Color(0xFFF5F6F8),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFE8EAEE),
    outlineVariant = Color(0xFFCDD1D8),
)

@Composable
fun AppTheme(mode: String, content: @Composable () -> Unit) {
    val dark = when (mode) {
        "light" -> false
        "system" -> isSystemInDarkTheme()
        else -> true
    }
    val scheme = if (dark) DarkScheme else LightScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = scheme.background.toArgb()
            window.navigationBarColor = scheme.background.toArgb()
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = !dark
            controller.isAppearanceLightNavigationBars = !dark
        }
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun isDarkUi(): Boolean = MaterialTheme.colorScheme.background.luminance() < 0.5f

/** Цвета подсветки карточек. */
class Highlight(val container: Color, val accent: Color)

object Highlights {
    // Готова к выдаче — зелёный
    fun ready(dark: Boolean) =
        if (dark) Highlight(Color(0xFF14341F), Color(0xFF4CAF50)) else Highlight(Color(0xFFDDF3E1), Color(0xFF2E7D32))

    // Готова к выдаче и лежит дольше порога — красный
    fun overdue(dark: Boolean) =
        if (dark) Highlight(Color(0xFF4A1A1A), Color(0xFFFF5252)) else Highlight(Color(0xFFFFDAD6), Color(0xFFC62828))

    // Проблема / возврат — янтарный
    fun problem(dark: Boolean) =
        if (dark) Highlight(Color(0xFF3A2D10), Color(0xFFFFB300)) else Highlight(Color(0xFFFFF0CC), Color(0xFFB26A00))
}
