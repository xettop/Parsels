package ua.parcels.tracker.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ua.parcels.tracker.MainVm
import ua.parcels.tracker.data.AppSettings
import ua.parcels.tracker.data.Carrier
import ua.parcels.tracker.data.Parcel
import ua.parcels.tracker.data.State
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun fmt(ts: Long?): String =
    if (ts == null) "—" else SimpleDateFormat("dd.MM HH:mm", Locale.US).format(Date(ts))

/** Порядок: просроченные → готовые → проблемные → в пути → полученные. */
private fun priority(p: Parcel, now: Long, threshold: Int): Int = when {
    p.isOverdue(now, threshold) -> 0
    p.stateEnum == State.READY -> 1
    p.stateEnum == State.PROBLEM -> 2
    p.stateEnum == State.DELIVERED -> 4
    else -> 3
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(vm: MainVm) {
    val active by vm.active.collectAsState()
    val archived by vm.archived.collectAsState()
    val busy by vm.busy.collectAsState()
    val settings by vm.settings.collectAsState()

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showAdd by rememberSaveable { mutableStateOf(false) }
    var showSettings by rememberSaveable { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<Parcel?>(null) }
    val snack = remember { SnackbarHostState() }
    val refreshing = busy > 0
    val dark = isDarkUi()

    LaunchedEffect(Unit) { vm.messages.collect { snack.showSnackbar(it) } }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Мои посылки", fontWeight = FontWeight.SemiBold) },
                colors = androidx.compose.material3.TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = MaterialTheme.colorScheme.onBackground,
                    actionIconContentColor = MaterialTheme.colorScheme.onBackground,
                ),
                actions = {
                    IconButton(onClick = { vm.refreshAll() }, enabled = !refreshing) {
                        if (refreshing) {
                            CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Default.Refresh, contentDescription = "Обновить статусы")
                        }
                    }
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Default.Settings, contentDescription = "Настройки")
                    }
                },
            )
        },
        floatingActionButton = {
            if (tab == 0) {
                FloatingActionButton(onClick = { showAdd = true }) {
                    Icon(Icons.Default.Add, contentDescription = "Добавить посылку")
                }
            }
        },
        snackbarHost = { SnackbarHost(snack) },
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            TabRow(
                selectedTabIndex = tab,
                containerColor = MaterialTheme.colorScheme.background,
                contentColor = MaterialTheme.colorScheme.primary,
            ) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Активные (${active.size})") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Архив (${archived.size})") })
            }

            if (tab == 0) Legend(settings.overdueDays, dark)

            val now = remember(active, archived, tab) { System.currentTimeMillis() }
            val list = remember(active, archived, tab, settings.overdueDays) {
                if (tab == 0) {
                    active.sortedWith(
                        compareBy<Parcel> { priority(it, now, settings.overdueDays) }
                            .thenByDescending { it.readySince?.let { r -> -r } ?: it.createdAt }
                    )
                } else archived
            }

            PullToRefreshBox(
                isRefreshing = refreshing,
                onRefresh = { vm.refreshAll() },
                modifier = Modifier.fillMaxSize(),
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 88.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    if (list.isEmpty()) {
                        item {
                            Text(
                                text = if (tab == 0) "Пока нет посылок.\nНажмите «+», чтобы добавить трек-номер."
                                else "Архив пуст.",
                                modifier = Modifier.fillMaxWidth().padding(top = 80.dp),
                                textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    } else {
                        items(list, key = { it.id }) { p ->
                            ParcelCard(
                                p = p,
                                now = now,
                                overdueDays = settings.overdueDays,
                                dark = dark,
                                onRefresh = { vm.refreshOne(p.id) },
                                onToggleArchive = { vm.setArchived(p, !p.archived) },
                                onDelete = { toDelete = p },
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAdd) {
        AddDialog(
            onDismiss = { showAdd = false },
            onAdd = { number, title, carrier, phone ->
                vm.add(number, title, carrier, phone)
                showAdd = false
            },
        )
    }
    if (showSettings) {
        SettingsDialog(
            current = settings,
            onDismiss = { showSettings = false },
            onSave = { vm.saveSettings(it); showSettings = false },
        )
    }
    toDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Удалить посылку?") },
            text = { Text("${p.title.ifBlank { p.number }} будет удалена без возможности восстановления.") },
            confirmButton = { TextButton(onClick = { vm.delete(p); toDelete = null }) { Text("Удалить") } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Отмена") } },
        )
    }
}

@Composable
private fun Legend(overdueDays: Int, dark: Boolean) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        LegendItem(Highlights.ready(dark).accent, "Можно забрать")
        LegendItem(Highlights.overdue(dark).accent, "Лежит > $overdueDays дн.")
    }
}

@Composable
private fun LegendItem(color: Color, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).background(color, CircleShape))
        Text(
            text,
            Modifier.padding(start = 6.dp),
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun ParcelCard(
    p: Parcel,
    now: Long,
    overdueDays: Int,
    dark: Boolean,
    onRefresh: () -> Unit,
    onToggleArchive: () -> Unit,
    onDelete: () -> Unit,
) {
    val st = p.stateEnum
    val overdue = p.isOverdue(now, overdueDays)
    val hl = when {
        overdue -> Highlights.overdue(dark)
        st == State.READY -> Highlights.ready(dark)
        st == State.PROBLEM -> Highlights.problem(dark)
        else -> null
    }
    val container = hl?.container ?: MaterialTheme.colorScheme.surface
    val border = if (hl != null) BorderStroke(2.dp, hl.accent)
    else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    val dim = st == State.DELIVERED || p.archived

    val badge: Pair<String, Color>? = when {
        overdue -> "Лежит ${p.readyDays(now) ?: 0} дн. — заберите!" to hl!!.accent
        st == State.READY -> {
            val d = p.readyDays(now) ?: 0
            (if (d >= 1) "Готова к выдаче · $d дн." else "Готова к выдаче") to hl!!.accent
        }
        st == State.PROBLEM -> "Проблема / возврат" to hl!!.accent
        st == State.DELIVERED -> "Получена" to MaterialTheme.colorScheme.onSurfaceVariant
        st == State.TRANSIT -> "В пути" to MaterialTheme.colorScheme.primary
        else -> null
    }

    var menu by remember { mutableStateOf(false) }
    val clipboard = LocalClipboardManager.current
    val uri = LocalUriHandler.current

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = container),
        border = border,
    ) {
        Column(Modifier.padding(start = 14.dp, end = 4.dp, top = 10.dp, bottom = 12.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f).padding(end = 8.dp, top = 4.dp)) {
                    if (p.title.isNotBlank()) {
                        Text(
                            p.title,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 16.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            color = if (dim) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                        )
                    }
                    Text(
                        "${p.carrierEnum.title} · ${p.number}",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Box {
                    IconButton(onClick = { menu = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "Меню")
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text("Обновить статус") }, onClick = { menu = false; onRefresh() })
                        DropdownMenuItem(
                            text = { Text("Открыть на сайте") },
                            onClick = { menu = false; uri.openUri(p.carrierEnum.siteUrl(p.number)) },
                        )
                        DropdownMenuItem(
                            text = { Text("Скопировать номер") },
                            onClick = { menu = false; clipboard.setText(AnnotatedString(p.number)) },
                        )
                        DropdownMenuItem(
                            text = { Text(if (p.archived) "Вернуть из архива" else "В архив") },
                            onClick = { menu = false; onToggleArchive() },
                        )
                        DropdownMenuItem(
                            text = { Text("Удалить") },
                            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null) },
                            onClick = { menu = false; onDelete() },
                        )
                    }
                }
            }

            Column(Modifier.padding(end = 10.dp)) {
                if (badge != null) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = badge.second.copy(alpha = 0.18f),
                        modifier = Modifier.padding(top = 6.dp),
                    ) {
                        Text(
                            badge.first,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = badge.second,
                        )
                    }
                }
                Text(
                    p.status.ifBlank { "Статус ещё не получен" },
                    modifier = Modifier.padding(top = 8.dp),
                    fontSize = 15.sp,
                    color = if (dim) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                )
                if (p.location.isNotBlank()) {
                    Text(
                        p.location,
                        modifier = Modifier.padding(top = 2.dp),
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (p.note.isNotBlank()) {
                    Text(
                        p.note,
                        modifier = Modifier.padding(top = 2.dp),
                        fontSize = 13.sp,
                        color = hl?.accent ?: MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                if (p.error != null) {
                    Text(
                        "Ошибка: ${p.error}",
                        modifier = Modifier.padding(top = 4.dp),
                        fontSize = 12.sp,
                        color = Color(0xFFFF8A80),
                    )
                }
                Text(
                    buildString {
                        append("Проверено: ${fmt(p.lastChecked)}")
                        if (st == State.READY && p.readySince != null) append(" · готова с ${fmt(p.readySince)}")
                        else if (p.lastChange != null) append(" · статус от ${fmt(p.lastChange)}")
                    },
                    modifier = Modifier.padding(top = 6.dp),
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AddDialog(onDismiss: () -> Unit, onAdd: (String, String, Carrier, String) -> Unit) {
    var number by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var carrier by remember { mutableStateOf(Carrier.NOVA) }
    var manual by remember { mutableStateOf(false) }

    LaunchedEffect(number) {
        if (!manual) Carrier.guess(number)?.let { carrier = it }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новая посылка") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = number,
                    onValueChange = { number = it },
                    label = { Text("Трек-номер") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Название (что заказано)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Text("Служба доставки", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Carrier.values().forEach { c ->
                        FilterChip(
                            selected = carrier == c,
                            onClick = { carrier = c; manual = true },
                            label = { Text(c.title) },
                        )
                    }
                }
                if (carrier == Carrier.NOVA) {
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Телефон получателя (если нужен)") },
                        placeholder = { Text("380XXXXXXXXX") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onAdd(number, title, carrier, phone) }, enabled = number.isNotBlank()) {
                Text("Добавить")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}

@Composable
private fun SettingsDialog(current: AppSettings, onDismiss: () -> Unit, onSave: (AppSettings) -> Unit) {
    var npKey by remember { mutableStateOf(current.npKey) }
    var upToken by remember { mutableStateOf(current.upToken) }
    var theme by remember { mutableStateOf(current.theme) }
    var days by remember { mutableStateOf(current.overdueDays.toString()) }
    var autoArchive by remember { mutableStateOf(current.autoArchive) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Настройки") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Тема", fontWeight = FontWeight.SemiBold)
                listOf("dark" to "Тёмная", "light" to "Светлая", "system" to "Как в системе").forEach { (key, label) ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = theme == key, onClick = { theme = key })
                        Text(label)
                    }
                }
                OutlinedTextField(
                    value = days,
                    onValueChange = { days = it.filter(Char::isDigit).take(2) },
                    label = { Text("Подсветка «лежит долго», дней") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = autoArchive, onCheckedChange = { autoArchive = it })
                    Text("Получено → сразу в архив", Modifier.padding(start = 12.dp))
                }
                Text("Ключи API", fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
                OutlinedTextField(
                    value = npKey,
                    onValueChange = { npKey = it },
                    label = { Text("Нова Пошта: API-ключ (необязательно)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = upToken,
                    onValueChange = { upToken = it },
                    label = { Text("Укрпошта: Bearer-токен статус-трекинга") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Text(
                    "Укрпошта отдаёт статусы только по токену (его выдаёт менеджер Укрпошти по договору). " +
                        "Для Новой Пошты ключ можно создать бесплатно в личном кабинете (Налаштування → Безпека). " +
                        "Meest работает без ключа.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onSave(
                    AppSettings(
                        npKey = npKey.trim(),
                        upToken = upToken.trim(),
                        theme = theme,
                        overdueDays = (days.toIntOrNull() ?: 4).coerceIn(1, 30),
                        autoArchive = autoArchive,
                    )
                )
            }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } },
    )
}
