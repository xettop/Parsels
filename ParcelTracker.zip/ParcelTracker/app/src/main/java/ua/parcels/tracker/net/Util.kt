package ua.parcels.tracker.net

import org.json.JSONObject
import ua.parcels.tracker.data.State
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone

/** org.json возвращает строку "null" для JSON null — этот хелпер возвращает пустую строку. */
fun JSONObject.str(key: String): String = if (isNull(key)) "" else optString(key).trim()

private val DATE_PATTERNS = listOf(
    "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
    "yyyy-MM-dd'T'HH:mm:ssXXX",
    "yyyy-MM-dd'T'HH:mm:ss",
    "yyyy-MM-dd HH:mm:ss",
    "yyyy-MM-dd HH:mm",
    "dd-MM-yyyy HH:mm:ss",
    "dd.MM.yyyy HH:mm:ss",
    "dd.MM.yyyy HH:mm",
    "yyyy-MM-dd",
    "dd.MM.yyyy",
)

/** Пробует несколько распространённых форматов дат. Время без пояса считается киевским. */
fun parseDate(raw: String?): Long? {
    val s = raw?.trim().orEmpty()
    if (s.isEmpty() || s == "null") return null
    for (p in DATE_PATTERNS) {
        try {
            val f = SimpleDateFormat(p, Locale.US)
            f.isLenient = false
            f.timeZone = TimeZone.getTimeZone("Europe/Kiev")
            val d = f.parse(s) ?: continue
            val year = SimpleDateFormat("yyyy", Locale.US).format(d).toInt()
            if (year in 2000..2100) return d.time
        } catch (_: Exception) {
        }
    }
    return null
}

private val PROBLEM_WORDS = listOf(
    "поверн", "возврат", "return", "відмов", "отказ", "не вручен", "не вруч", "знищен", "уничтож",
    "втрачен", "утерян", "припинено зберігання", "refus",
)
private val DELIVERED_WORDS = listOf(
    "вручен", "видано одержувач", "видано отримувач", "отримано одержувач", "отримано отримувач",
    "доставлено одержувач", "получен получател", "выдан получател", "delivered",
)
private val READY_WORDS = listOf(
    "очікує одержувача", "очікує отримувача", "очікує у відділенні", "очікує в відділенні",
    "очікує вручення", "очікує на отримання", "очікує на видачу", "прибуло до відділення",
    "прибув до відділення", "прибуло у відділення", "прибув у відділення", "прибуло в відділення",
    "прибуло в місце вручення", "прибуло до місця вручення", "місце вручення", "готов до видач",
    "готове до видач", "готова до видач", "готово до видач", "в поштоматі", "у поштоматі",
    "до видачі", "ожидает получателя", "ожидает в отделении", "прибыл в отделение",
    "прибыло в отделение", "готов к выдаче", "готово к выдаче", "ready for pickup",
    "ready for collection", "arrived at pickup", "awaiting collection",
)
private val TRANSIT_HINTS = listOf("в дорозі", "в пути", "transit", "прямує", "відправлено", "передано", "прийнято", "сортув")

/** Определяет состояние по тексту статуса (для Укрпошти и Meest). */
fun classify(raw: String): State {
    val t = raw.lowercase(Locale.ROOT)
    if (t.isBlank()) return State.UNKNOWN
    return when {
        PROBLEM_WORDS.any { t.contains(it) } -> State.PROBLEM
        DELIVERED_WORDS.any { t.contains(it) } -> State.DELIVERED
        READY_WORDS.any { t.contains(it) } -> State.READY
        TRANSIT_HINTS.any { t.contains(it) } -> State.TRANSIT
        else -> State.TRANSIT
    }
}
